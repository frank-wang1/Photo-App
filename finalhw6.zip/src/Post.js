import React from 'react';
import LikeButton from './LikeButton';
import BookmarkButton from './BookmarkButton';
import {getHeaders} from './utils';
import AddComment from './AddComment';
import Comment from './Comment';
import Comments from './Comments';

class Post extends React.Component {
  
    constructor(props) {
        super(props);
        this.state = {
            post: null
        }
        this.refreshPostDataFromServer = this.refreshPostDataFromServer.bind(this);
    }


    componentDidMount() {
        this.setState({post: this.props.model})
    }


    refreshPostDataFromServer () {
        const url = '/api/posts/' + this.state.post.id;
        fetch(url, {
            headers: getHeaders()
        }).then(response => response.json())
        .then(data => {
            console.log(data);
            this.setState({
                post: data
            })
        })
    }

     render () {
        const post = this.state.post;
        if (!post) {
            return (
                <div></div>  
            );
        }
        return (
            <section 
                className = "card">
                <div className="topcard">
                    <p>{post.user.username}</p>
                    <i class="fas fa-ellipsis-h"></i>
                </div>
                <img src={post.image_url} />
                <section className = "iconsection">
                    <div className="iconsleft">
                        <LikeButton 
                        likeId={post.current_user_like_id}
                        postId={post.id}
                        refreshPost = {this.refreshPostDataFromServer}/>
                        <i class="far fa-comment"></i>
                        <i class="far fa-paper-plane"></i>
                    </div>
                    <BookmarkButton 
                        bookmarkId={post.current_user_bookmark_id}
                        postId={post.id}
                        refreshPost = {this.refreshPostDataFromServer}/>
                </section>
                <div>
                    <p>
                        <span><strong>{post.user.username}</strong></span>
                        {post.caption}
                    </p>
                </div>
                <Comments comments={post.comments}  />
                <AddComment callback={this.refreshPostDataFromServer} postId={post.id} />
                
            </section>
        )
    }
}

export default Post;