import React from 'react';
import {getHeaders} from './utils';
import Post from './Post';

class Posts extends React.Component {
  
    constructor(props) {
        super(props);
        this.state = {
            posts: null
        }
        // initialization code here
        this.getPostsFromServer =  this.getPostsFromServer.bind(this);
    }

    getPostsFromServer () {
        fetch('/api/posts', {
            headers: getHeaders()
        }).then(response => response.json())
        .then(data => {
            // console.log(data);
            this.setState({
                posts: data
            })
        })
    }
    componentDidMount() {
        this.getPostsFromServer();
    }

     render () {
        if (!this.state.posts) {
            return (
                <div></div>  
            );
        }
         return (
             <div id="posts">
                    {
                        this.state.posts.map(post => {
                            // console.log(post);
                            return (
                                <Post 
                                    key={'post_' + post.id}
                                    model={post} />
                            )
                        })
                    }
                    </div>
                )
                }
}

export default Posts;