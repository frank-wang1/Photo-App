import React from 'react';
import LikeButton from './LikeButton';
import BookmarkButton from './BookmarkButton';
import {getHeaders} from './utils';

class Suggestion extends React.Component {
  
    constructor(props) {
        super(props);
        this.state = {
            suggestion: props.model,
            request_id: 0,
            followed:'follow'

        }
        // this.refreshSuggestionDataFromServer = this.refreshSuggestionDataFromServer.bind(this);
        this.toggleFollow = this.toggleFollow.bind(this)
        this.createFollow = this.createFollow.bind(this)
        this.removeFollow = this.removeFollow.bind(this)
    }


    componentDidMount() {
        // fetch posts and then set the state...
    }


    toggleFollow() {
        if(this.state.followed == 'unfollow') {
            this.removeFollow();
        } else {
            this.createFollow();
        }
    }

    createFollow () {
        const url = 'api/following';
        const suggestionData = {
            user_id: this.state.suggestion.id
        }
        console.log('create follow:', url);
        fetch(url, {
            headers: getHeaders(),
            method: 'POST',
            body: JSON.stringify(suggestionData)
        }).then(response => response.json())
        .then(data => {
            console.log(data);
            this.setState({
                request_id: data.id,
                followed: 'unfollow'
            })
            
        })
    }

    removeFollow () {
        const url = 'api/following/' + this.state.request_id;
        console.log('remove follow:', url);
        fetch(url, {
            headers: getHeaders(),
            method: 'DELETE'
        }).then(response => response.json())
        .then(data => {
            // console.log(data);
            this.setState({
                followed: 'follow'
            })
        })
    }

    // refreshSuggestionDataFromServer () {
    //     const url = '/api/suggestions/' + this.state.suggestion.id;
    //     fetch(url, {
    //         method: 'GET',
    //         headers: getHeaders()
    //     }).then(response => response.json())
    //     .then(data => {
    //         console.log(data);
    //         this.setState({
    //             suggestion: data
    //         })
    //     })
    // }

     render () {
        const suggestion = this.state.suggestion;
        const followed = this.state.followed
        return (
            <section className='suggestion'>
                <img src={suggestion.thumb_url} />
                <p>{suggestion.username}</p>
                <button 
                    onClick={this.toggleFollow}
                    aria-label="Followed / Unfollow">
                    {followed}
                </button>
                <div>
                    suggested for you
                </div>
            </section>
        )
    }
}

export default Suggestion;