import React from 'react';

class Stories extends React.Component {
  
    constructor(props) {
        super(props);
        // initialization code here
    }

    componentDidMount() {
        // fetch posts and then set the state...
    }

     render () {
        return (
            <header className="stories">
                Stories
                {/* Stories */}
            </header>
        )
     }
}

export default Stories;