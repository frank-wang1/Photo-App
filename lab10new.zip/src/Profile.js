import React from 'react';
import {getHeaders} from './utils';
class Profile extends React.Component {
  
    constructor(props) {
        super(props);
        this.state = {
            profile: []
        }
        // initialization code here
    }

    componentDidMount() {
        // fetch posts and then set the state...
        this.getProfileFromServer()
    }

    getProfileFromServer () {
        fetch('/api/profile', {
            method: 'GET',
            headers: getHeaders()
        }).then(response => response.json())
        .then(data => {
            // console.log(data);
            this.setState({
                profile: data
            })
        })
    }

     render () {
        const profile = this.state.profile;
        return (
            <header>
                <div>
                <img src={profile.thumb_url} />
                <h2>{profile.username}</h2>
                </div>
            </header>
        )
     }
}

export default Profile;