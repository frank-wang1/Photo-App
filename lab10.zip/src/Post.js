import React from 'react';
import {getHeaders} from './utils';
import LikeButton from './LikeButton';

class Post extends React.Component {  

    constructor(props) {
        super(props);
        // constructor logic
    }


    componentDidMount() {
        // fetch posts
        console.log('Posts component mounted');
    }
    
    render () {
        const post = this.props.model;
        return (
                            <section
                                className='card'>
                                <img src={post.image_url} />
                                <p>{post.caption}</p>
                                <LikeButton 
                                    likeId={post.current_user_like_id}
                                    postId={post.id}/>
                                <button><i className="fas fa-bookmark"></i></button>
                            </section>
                )  
    }
}

export default Post;