import React from 'react';
import {getHeaders} from './utils';
class Stories extends React.Component {
  
    constructor(props) {
        super(props);
        this.state = {
            stories: []
        }
        // initialization code here
        this.getStoriesFromServer()
        // initialization code here
    }

    componentDidMount() {
        // fetch posts and then set the state...
    }

    getStoriesFromServer () {
        fetch('/api/stories', {
            headers: getHeaders()
        }).then(response => response.json())
        .then(data => {
            console.log(data);
            this.setState({
                stories: data
            })
        })
    }

     render () {
        return (
            <header className="stories">
                {
                this.state.stories.map(story => {
                            console.log(story);
                            return (
                                <img src={story.user.image_url} />
                            )
                        })
                }
            </header>
        )
     }
}

export default Stories;