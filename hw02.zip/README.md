## Installation

See Lab 2 (https://cs396-web-dev.github.io/spring2022/assignments/lab02) for instructions on how to:

1. set up your virtual environment,
2. install the dependencies,
3. set up the Flask environment variables, and 
4. run your Flask app